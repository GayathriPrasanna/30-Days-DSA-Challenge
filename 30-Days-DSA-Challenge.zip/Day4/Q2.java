// Q2 solution for Day 4

public class Q2 {
    public static void main(String[] args) {
        // TODO: Add code here
    }
}