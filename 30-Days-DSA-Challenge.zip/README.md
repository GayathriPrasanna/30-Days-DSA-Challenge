# 30 Days DSA Challenge (Java)

| Day | Status |
|-----|--------|
| [Day 1](./Day1) | ⏳ |
| [Day 2](./Day2) | ⏳ |
| [Day 3](./Day3) | ⏳ |
| [Day 4](./Day4) | ⏳ |
| [Day 5](./Day5) | ⏳ |
| [Day 6](./Day6) | ⏳ |
| [Day 7](./Day7) | ⏳ |
| [Day 8](./Day8) | ⏳ |
| [Day 9](./Day9) | ⏳ |
| [Day 10](./Day10) | ⏳ |
| [Day 11](./Day11) | ⏳ |
| [Day 12](./Day12) | ⏳ |
| [Day 13](./Day13) | ⏳ |
| [Day 14](./Day14) | ⏳ |
| [Day 15](./Day15) | ⏳ |
| [Day 16](./Day16) | ⏳ |
| [Day 17](./Day17) | ⏳ |
| [Day 18](./Day18) | ⏳ |
| [Day 19](./Day19) | ⏳ |
| [Day 20](./Day20) | ⏳ |
| [Day 21](./Day21) | ⏳ |
| [Day 22](./Day22) | ⏳ |
| [Day 23](./Day23) | ⏳ |
| [Day 24](./Day24) | ⏳ |
| [Day 25](./Day25) | ⏳ |
| [Day 26](./Day26) | ⏳ |
| [Day 27](./Day27) | ⏳ |
| [Day 28](./Day28) | ⏳ |
| [Day 29](./Day29) | ⏳ |
| [Day 30](./Day30) | ⏳ |
