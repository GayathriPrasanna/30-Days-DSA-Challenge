// Q3 solution for Day 12

public class Q3 {
    public static void main(String[] args) {
        // TODO: Add code here
    }
}