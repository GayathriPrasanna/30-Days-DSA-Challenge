// Q1 solution for Day 13

public class Q1 {
    public static void main(String[] args) {
        // TODO: Add code here
    }
}