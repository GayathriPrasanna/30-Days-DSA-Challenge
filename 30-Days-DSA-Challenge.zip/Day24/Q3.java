// Q3 solution for Day 24

public class Q3 {
    public static void main(String[] args) {
        // TODO: Add code here
    }
}