// Q2 solution for Day 30

public class Q2 {
    public static void main(String[] args) {
        // TODO: Add code here
    }
}